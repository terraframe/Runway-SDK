<?php
/* 
	To run sample application you need to have:
	- PHP
	- MySQL
	
	To install application, just make sure that your MySQL running and load index.php 
	after entering suitable (for you) information below
*/
    $mysql_host = "localhost";
    $mysql_user = "root";
    $mysql_pasw = "1";
    $mysql_db   = "sampleDB";
?>
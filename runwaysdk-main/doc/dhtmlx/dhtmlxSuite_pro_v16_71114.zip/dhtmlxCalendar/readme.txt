dhtmlxCalendar v.1.0 Standard edition build 71114

(c) DHTMLX Ltd. 
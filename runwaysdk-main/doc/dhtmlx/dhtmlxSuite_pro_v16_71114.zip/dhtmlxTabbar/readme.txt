dhtmlxTabbar v.1.2 Professional edition build 71114

(c) DHTMLX Ltd. 
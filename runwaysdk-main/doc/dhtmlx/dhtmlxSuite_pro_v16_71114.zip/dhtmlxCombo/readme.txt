dhtmlxCombo v.1.2 Standard edition build 71114

(c) DHTMLX Ltd. 